import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: Scaffold(
        appBar: AppBar(
          title: Text('FCOMEASY'),
          backgroundColor: Colors.black12,
        ),
        backgroundColor: Colors.white,
        body: SafeArea(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: <Widget>[
              Container(
                height: 100.0,
                width: double.infinity,
                decoration: BoxDecoration(
                  boxShadow: const [
                    BoxShadow(
                      blurRadius: 10,
                    )
                  ],
                  gradient: LinearGradient(colors: const [
                    Colors.red,
                    Colors.orange,
                  ]),
                ),
                child: Text('Container 4'),
              ),
              SizedBox(
                height: 20.0,
              ),
              Container(
                height: 100.0,
                width: double.infinity,
                decoration: BoxDecoration(
                  boxShadow: const [
                    BoxShadow(
                      blurRadius: 10,
                    )
                  ],
                  gradient: LinearGradient(colors: const [
                    Colors.red,
                    Colors.orange,
                  ]),
                ),
                child: Text('Container 4'),
              ),
              SizedBox(
                height: 20.0,
              ),
              Container(
                height: 100.0,
                width: double.infinity,
                decoration: BoxDecoration(
                  boxShadow: const [
                    BoxShadow(
                      blurRadius: 10,
                    )
                  ],
                  gradient: LinearGradient(colors: const [
                    Colors.red,
                    Colors.orange,
                  ]),
                ),
                child: Text('Container 4'),
              ),
              SizedBox(
                height: 20.0,
              ),
              Container(
                height: 100.0,
                width: double.infinity,
                decoration: BoxDecoration(
                  boxShadow: const [
                    BoxShadow(
                      blurRadius: 10,
                    )
                  ],
                  gradient: LinearGradient(colors: const [
                    Colors.red,
                    Colors.orange,
                  ]),
                ),
                child: Text('Container 4'),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
